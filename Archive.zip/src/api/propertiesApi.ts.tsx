// src/api/propertiesApi.ts
import { generateClient } from 'aws-amplify/data';
import { type Schema } from '../../amplify/data/resource';
import { Location} from "../interfaces/SearchInterface.tsx";
import {NewPropertyType, PropertyInterface} from "../interfaces/interfaces.tsx";
const client = generateClient<Schema>();

type Filter = {
    locationRadius?: {
        eq: number;
    };
    locations?: {
        contains: string[];
    };
    maxBedroom?: {
        le: number;
    };
    minBedroom?: {
        ge: number;
    };
    maxValuation?: {
        le: number;
    };
    minValuation?: {
        ge: number;
    };
    type?: {
        contains: string;
    };
    bedrooms?: {
        ge?: number;
        le?: number;
    };
};

// Function to list all properties
export const listProperties = async ():Promise<object> => {
    const { data: properties, errors } = await client.models.Property.list();
    if (errors) {
        console.error(errors);
        throw new Error('Failed to fetch properties');
    }
    return properties;
};

//
// export const searchProperties = async (filterValues):Promise<PropertyFilter> => {
//     console.log('FILTER', filterValues);
//
//     const filterQuery = buildFilter(
//         filterValues.locations || [],
//         filterValues.locationRadius || 0.0,
//         filterValues.minValuation || 1000,
//         filterValues.maxValuation || 20000000,
//         filterValues.type || 'All',
//         filterValues.minBedroom || 0,
//         filterValues.maxBedroom || 50
//     );
//
//     console.log('FILTER', filterQuery);
//
//
//         // const {
//         //     data: propertiesData,
//         //     errors
//         // } =     await client.models.Property.list({filter: filterQuery});
//         //
//         // if (errors) {
//         //     console.error(errors);
//         //     throw new Error('Failed to fetch properties');
//         // }
//         //
//         // return propertiesData;
//
//
// };
//
// export default searchProperties;

// Function to get a specific property by ID
export const getProperty = async (id: string):Promise<NewPropertyType> => {
    const { data: apiProperty, errors } = await client.models.Property.get({ id });
    // First, check for API-reported errors
    if (errors) {
        console.error(errors);
        throw new Error(`Failed to fetch property with ID ${id}`);
    }

    // Check if the data returned is null
    if (!apiProperty) {
        throw new Error(`property with ID ${id} not found`);
    }

    // Transform API response

    // Ensure all fields match the type, especially `id`
    const propertyData: NewPropertyType = {
        id: apiProperty.id ?? null, // Handle undefined by converting it to null
        title: apiProperty.title,
        slug: apiProperty.slug,
        valuation: apiProperty.valuation,
        min: apiProperty.min,
        max: apiProperty.max,
        description: apiProperty.description,
        address: apiProperty.address,
        town: apiProperty.town,
        city: apiProperty.city,
        county: apiProperty.county,
        postcode: apiProperty.postcode,
        condition: apiProperty.condition,
        country: apiProperty.country,
        bedrooms: apiProperty.bedrooms,
        bathrooms: apiProperty.bathrooms,
        garages: apiProperty.garages,
        area_size: apiProperty.area_size,
        year_built: apiProperty.year_built,
        views: apiProperty.views,
        is_featured: apiProperty.is_featured,
        is_published: apiProperty.is_published,
        is_sold: apiProperty.is_sold,
        is_yeoley_plus: apiProperty.is_yeoley_plus,
        user_id: apiProperty.user_id,
        type: apiProperty.type,
        longitude: apiProperty.longitude,
        latitude: apiProperty.latitude,
        valuation_type: apiProperty.valuation_type,
        prefix: apiProperty.prefix,
        tenure: apiProperty.tenure,
        current_epc_rating: apiProperty.current_epc_rating,
        potential_epc_rating: apiProperty.potential_epc_rating,
        epc_date: apiProperty.epc_date,
        layout: apiProperty.layout,
        content: apiProperty.content,
        createdAt: apiProperty.createdAt ?? null,
        updatedAt: apiProperty.updatedAt ?? null,
    };


    console.log('Transformed Property Data:', propertyData);

    return propertyData;
};


export const createProperty = async (property: NewPropertyType):Promise<PropertyInterface> => {
    const { data: todo, errors } = await client.models.Property.create(property);
    if (errors) {
        console.error(errors);
        throw new Error('Failed to create property');
    }
    if (!todo) {
        console.error(errors);
        throw new Error('Failed to create property');
    }
    return todo;
}

export const buildFilter = (
    locations: Location[],
    locationRadius: number | null,
    minValuation: number | null,
    maxValuation: number | null,
    propertyType: string | null,
    minBedroom: number | null | string,
    maxBedroom: number | null | string
): Filter => {

    const filter: Filter = {};

    if (locations && locations.length > 0) {
        filter.locations = {
            contains: locations.map(location => location.name.toLowerCase())
        };
    }

    if (locationRadius) {
        filter.locationRadius = {
            eq: locationRadius
        };
    }

    if (minValuation) {
        filter.minValuation = {
            ge: Number(minValuation)
        };
    }

    if (maxValuation) {
        filter.maxValuation = {
            le: Number(maxValuation)
        };
    }

    if (propertyType && propertyType !== 'All') {
        filter.type = {
            contains: propertyType
        };
    }

    if (minBedroom) {
        filter.minBedroom = {
            ge: Number(minBedroom)
        };
    }

    if (maxBedroom) {
        if (!filter.bedrooms) {
            filter.bedrooms = {};
        }
        filter.bedrooms.le = Number(maxBedroom);
    }

    console.log('filter', filter);

    return filter;
};
