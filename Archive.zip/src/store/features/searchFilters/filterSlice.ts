import { createSlice } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'
import {DataItem, DataRadiusItem, PropertyFilter} from "../../../interfaces/interfaces.tsx";
import {NumberTypeInterface} from "../../../interfaces/interfaces.tsx";


const initialState = {
    locations: [
        { id: 1, name: 'New York' },
        { id: 2, name: 'Los Angeles' },
    ],
    type: 'All',
    locationRadius: 0.0,
    minBedroom: 0,
    maxBedroom: 99,
    minValuation: 0,
    maxValuation: 20000000,
    maxOfferPrice: 500000
}

export const filterSlice = createSlice({
    name: 'filters',
    initialState,
    reducers: {
        locations: (state,acton:PayloadAction<PropertyFilter>) => {
            state.locations = acton.payload.locations
            console.log('locations payload',acton.payload);
        },
        locationRadius: (_state,acton:PayloadAction<DataRadiusItem>) => {
            console.log('current State',_state);
            console.log('locationRadius payload',acton.payload);
        },
        type: (state,acton:PayloadAction<DataItem>) => {
            state.type = acton.payload.name
            console.log('type payload',acton.payload);
            console.log('type reduced',state.type);
        },
        minBedroom: (state,acton:PayloadAction<NumberTypeInterface>) => {
            console.log('type payload',acton.payload.value);
            state.minBedroom = acton.payload.value
        },
        maxBedroom: (state,acton:PayloadAction<NumberTypeInterface>) => {
            state.maxBedroom = acton.payload.value
        },
        minValuation: (state,acton:PayloadAction<DataRadiusItem>) => {
            state.minValuation = acton.payload.value
        },
        maxValuation: (state,acton:PayloadAction<DataRadiusItem>) => {
            state.maxValuation = acton.payload.value
        },

        maxOfferPrice: (state,acton:PayloadAction<DataRadiusItem>) => {
            state.maxOfferPrice = acton.payload.value
        },
    },
})

// Action creators are generated for each case reducer function
export const {
    locations,
    locationRadius,
    type,
    minBedroom,
    maxBedroom,
    minValuation,
    maxValuation,
    maxOfferPrice
} = filterSlice.actions

export default filterSlice.reducer