import React from 'react';
import { Link } from "react-router-dom";
import {PropertyInterface} from "../interfaces/interfaces.tsx";
interface PropertyCardProps {
    property: PropertyInterface;
}

const PropertyCardList :  React.FC<PropertyCardProps> = ({ property }) => {

    return (
        <div
            id={property.id}
            key={property.id}
            className='my-6 '
        >
            <Link to={`/search/properties/${property.id}`}>
                <div className={`group relative cursor-pointer border-[0.5rem] ${property.is_featured ? "border-yellow-300" : "border-grey-200"}  
                rounded-[0.5rem] shadow grid grid-cols-1 md:grid-cols-2 mr-4 md:mr-0 `}>

                    <div className="flex flex-col col-span-1">
                        <div className="relative flex flex-row space-x-1">
                            <div className="absolute left-0  w-[158px] h-[94px] cardTop-img flex flex-col items-start pl-5 justify-start">
                                <div className="text-sm">Max Offer</div>
                                <div className="font-semibold">
                                    {property ? `£${new Intl.NumberFormat('en-GB').format(property.max)}` : ''}
                                </div>
                            </div>
                            <img
                                alt={property.title}
                                src={property.imageSrc ?? 'https://media.rightmove.co.uk/37k/36689/145771118/36689_TES240020_IMG_18_0000.jpeg'}
                                className="object-cover object-center
                                max-w-full
                                xl:max-w-[218px]
                                h-96
                                xl:h-72
                                lg:w-full
                                cursor-pointer
                                rounded-2xl
                                xl:p-0.0

                                xl:rounded-[0rem]"
                            />
                            <img
                                alt={property.title}
                                src={property.imageSrc ?? 'https://media.rightmove.co.uk/37k/36689/145771118/36689_TES240020_IMG_18_0000.jpeg'}
                                className="object-cover object-center max-w-[218px]
                               xl:h-72 lg:w-full cursor-pointer hidden xl:block"
                            />
                        </div>
                    </div>

                    <div className="p-5 flex flex-col justify-between">
                        <div className="px-5">
                            <span >{property.title} </span>
                            <div className=" mt-2 text-xs flex flex-wrap items-center gap-4">
                                <div className="flex items-center gap-2">
                                    <a href="#" className="cursor-pointer text-xs  font-medium leading-none text-gray-900 underline hover:no-underline dark:text-white  ">34.5k views</a>
                                </div>

                                <div className="flex items-center gap-1.5 align-middle">
                                    <p className="text-xs  font-medium text-primary-700 dark:text-primary-500">Condition:</p>
                                    <span className=" text-xs font-bold text-base underline"> A </span>
                                </div>

                                <div className="flex items-center gap-1.5">
                                    <svg className="h-3 w-3 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9h13a5 5 0 0 1 0 10H7M3 9l4-4M3 9l4 4" />
                                    </svg>
                                    <p className="text-xs  font-normal text-gray-500 dark:text-gray-400">Telford Shropshire</p>
                                </div>
                            </div>
                            <p className=" my-2 text-sm text-gray-700 whitespace-pre-line mb-2">{property.content}</p>

                        </div>

                        <div className="flex flex-row justify-between items-center">
                            <div className=" flex flex-col items-start pl-5 justify-start">
                                <div className="text-sm">Valuation</div>
                                <div className="font-semibold">
                                    {property ? `£${new Intl.NumberFormat('en-GB').format(property.valuation)}` : ''}
                                </div>
                            </div>
                            <div className="flex">
                                <div className="mr-4 flex-shrink-0 self-center">
                                    <img src="https://media.rightmove.co.uk/company/clogo_14060_0001.jpeg"  className="max-h-10   bg-white"/>

                                </div>
                                <div>
                                    <h4 className="text-sm font-bold">Yeoley Direct</h4>
                                    <p className="mt-1 text-xs">
                                        0800 000 000 .
                                    </p>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
            </Link>
        </div>
    );
}

export default PropertyCardList;
