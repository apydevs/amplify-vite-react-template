export interface UserInterface {
    username: string;
    userId: string;
    signInDetails: any; // Adjust according to the actual data type you expect
}
