export interface CreateFavouriteParams {
    propertyId: string;
    userId: string;
}

export interface AddFavoritesProps {
    propertyId: string;
}